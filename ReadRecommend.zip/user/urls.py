# 设置url路径
# 也就是设置网页访问url时对应的处理函数
from django.urls import path
from . import views


app_name = 'user'
urlpatterns = [
    path('register/', views.RegisterView.as_view(), name='register'),  # 注册
    path('login/', views.LoginView.as_view(), name='login'),  # 登录
    path('logout/', views.logout_, name='logout'),  # 注销
]  
