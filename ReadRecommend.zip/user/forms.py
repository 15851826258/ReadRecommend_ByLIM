from django.forms import Form, CharField, ValidationError


class BaseForm(Form):
    def get_error(self):
        return self.errors.popitem()[1][0]


class LoginForm(BaseForm):

    username = CharField(max_length=20, required=True)
    password = CharField(max_length=20, required=True)


class RegisterForm(BaseForm):
    username = CharField(max_length=20, required=True)
    password = CharField(max_length=20, required=True)
    repeat_password = CharField(max_length=20, required=True)

    def clean_repeat_password(self):
        password = self.cleaned_data['password']
        repeat_password = self.cleaned_data['repeat_password']
        if repeat_password != password:
            raise ValidationError('Entered passwords do not match')
        else:
            return repeat_password
