# 视图函数文件，处理用户请求
from django.shortcuts import render, redirect, reverse
from django.views import View
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import LoginForm, RegisterForm
from .utils import add_user
from ReadRecommend.namespace import CURRENT_USER_ID


class LoginView(View):
    # 登录
    # get方法，直接渲染页面，传入message
    # render: 渲染一个html，context为传入html的参数
    def get(self, request, message=None):
        context = {}
        if not message:
            message = request.GET.get('message')
        if message:
            context['message'] = message
        return render(request, 'user/login.html', context=context)

    # post方法，处理用户提交的登录信息，根据处理结果做不同的返回
    def post(self, request):
        form = LoginForm(request.POST)  # 将提交的数据先传入表单做个验证，参看表单
        if form.is_valid():
            # 通过表单验证，开始处理
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)  #验证用户名与密码
            if user:
                # 验证通过，user登录，存入session中，以便于后续使用
                login(request, user)
                return redirect(reverse('reading:index'))
            else:
                # 验证不通过，获取错误信息，返回get方法，传入message
                message = 'Incorrect password'
                return self.get(request, message)
        else:
            # 未通过表单验证，从未通过的错误中取出一个，返回get方法，传入message
            message = form.get_error()
            return self.get(request, message=message)


class RegisterView(View):
    # 注册
    # get方法，直接渲染页面，传入message
    def get(self, request, message=None):
        context = {}
        if not message:
            message = request.GET.get('message')
        if message:
            context['message'] = message
        return render(request, 'user/register.html', context=context)

    # post方法，处理用户提交的注册信息，根据处理结果做不同的返回
    def post(self, request):
        form = RegisterForm(request.POST)  # 将提交的数据先传入表单做个验证，参看表单
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            result = add_user(username, password)  #添加用户
            if result['code'] == 200:
                # 成功，跳转到登录页面
                return redirect(reverse('user:login') + f'?message={result["message"]}')
            else:
                message= result['message']
                return self.get(request, message)
        else:
            message = form.errors.popitem()[1][0]
            return self.get(request, message=message)


@login_required
def logout_(request):
    # 注销
    logout(request)
    return redirect(reverse('user:login'))