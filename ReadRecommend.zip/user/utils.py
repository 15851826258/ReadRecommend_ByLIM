from django.contrib.auth.models import models, User
from reading.models import Collection
from ReadRecommend.restful import error_response, success_response


def get_user_by_username(username) -> User:
    # 通过用户名获取用户
    user = None
    try:
        user = User.objects.get(username=username)
    except:
        pass
    return user


def add_user(username, password):
    user = get_user_by_username(username)
    if user:
        return error_response(message='Username has been registered')
    user = User.objects.create(username=username, password=password)
    collection = Collection.objects.create(name='main', user=user)
    return success_response(message='Successfully registered')

