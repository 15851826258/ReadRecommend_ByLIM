def restful_response(code, message, data):
    return {'code': code, 'message': message, 'data': data}


def success_response(message='', data=None):
    return restful_response(200, message, data)


def error_response(message='', data=None):
    return restful_response(400, message, data)