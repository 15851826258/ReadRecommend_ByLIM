from django.forms import Form, CharField, ValidationError


class BaseForm(Form):
    def get_error(self):
        return self.errors.popitem()[1][0]


class CollectionForm(BaseForm):
    name = CharField(max_length=30, required=True)
