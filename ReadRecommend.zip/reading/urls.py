# 设置url路径
# 也就是设置网页访问url时对应的处理函数
from django.urls import path
from . import views


app_name = 'reading'
urlpatterns = [
    path('', views.index, name='index'),
    path('collections/all/', views.collections_all, name='collection_all'),
    path('collections/my/', views.MyCollectionsView.as_view(), name='collection_my'),
    # path('collections/', views.collection, name='collection'),
]
