from django.shortcuts import render, reverse, redirect
from .models import Collection, Book
from django.views import View
from .forms import CollectionForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from .utils import add_collection


def index(request):
    return render(request, 'reading/index.html')


def collections_all(request):
    context = {}
    kw = request.GET.get('kw')
    if kw:
        collections = Collection.objects.filter(name__icontains=kw).order_by('-modify_datetime').all()
    else:
        collections = Collection.objects.order_by('-modify_datetime').all()
    context['collections'] = collections
    return render(request, 'reading/collection_all.html', context=context)


class MyCollectionsView(LoginRequiredMixin, View):
    def get(self, request, message=None):
        context = {}
        if not message:
            message = request.GET.get('message')
        if message:
            context['message'] = message
        kw = request.GET.get('kw')
        if kw:
            collections = Collection.objects.filter(user=request.user)\
                .filter(name__icontains=kw).order_by('-modify_datetime').all()
        else:
            collections = Collection.objects.filter(user=request.user).order_by('-modify_datetime').all()
        context['collections'] = collections
        return render(request, 'reading/collection_my.html', context=context)

    def post(self, request):
        form = CollectionForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            result = add_collection(name, request.user)
            return self.get(request, message=result['message'])
        else:
            message = form.get_error()
            return self.get(request, message=message)


# @login_required
# def collections_my(request):
#     context = {}
#     collections = Collection.objects.filter(user=request.user).order_by('-modify_datetime').all()
#     context['collections'] = collections
#
#     return render(request, 'reading/collections.html', context=context)


# def books(request):
#     context = {}
#     books = Book.objects.all()
#     context['books'] = books
#
#     return