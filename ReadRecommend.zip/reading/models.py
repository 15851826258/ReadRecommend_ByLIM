from django.db import models
from django.contrib.auth.models import User


class Book(models.Model):
    title = models.CharField(max_length=100, verbose_name='title')
    authors = models.CharField(max_length=300, verbose_name='authors')
    publisher = models.CharField(max_length=200, verbose_name='punlisher')
    publication_date = models.DateField(verbose_name='publication date')
    category = models.CharField(max_length=50, verbose_name='category')

    @classmethod
    def rating(self):
        sum = 0
        ratings = self.rating_set.all()
        for r in ratings:
            sum += r.rating
        average = round(sum/len(ratings))
        return average

    def __str__(self):
        return f'{self.title}'

    class Meta:
        verbose_name = 'book'
        verbose_name_plural = 'book'


class Rating(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='user')
    book = models.ForeignKey(Book, on_delete=models.CASCADE, verbose_name='book')
    rating = models.FloatField(verbose_name='rating stars')

    def __str__(self):
        return f'{self.user.username}-{self.book.title}-{str(self.rating)}'

    class Meta:
        verbose_name = 'rating_record'
        verbose_name_plural = 'rating_record'


class Collection(models.Model):
    name = models.CharField(max_length=30, verbose_name='name')
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='user')
    book = models.ManyToManyField(Book, verbose_name='book')
    modify_datetime = models.DateTimeField(auto_now=True, verbose_name='last modified time')

    def __str__(self):
        return f'{self.user.username}-{self.name}'

    class Meta:
        verbose_name = 'collection'
        verbose_name_plural = 'collection'