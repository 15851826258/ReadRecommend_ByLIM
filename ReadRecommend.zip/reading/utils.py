from .models import Collection, models
from ReadRecommend.restful import error_response, success_response


def add_collection(name, user):
    collection = Collection.objects.filter(name=name).filter(user=user).all()
    if len(collection) > 0:
        return error_response(message='This name has been created')
    else:
        collection = Collection.objects.create(name=name, user=user)
        return success_response(message='Successfully added')